import express from "express";
import http from "http";
import path from "path";
import { WebSocketServer, WebSocket } from "ws";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const server = http.createServer(app);
const PORT = 3000;

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "healthy", timestamp: new Date().toISOString() });
});

// Cache GenAI instance
let aiInstance: GoogleGenAI | null = null;
function getGenAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("⚠️ Warning: GEMINI_API_KEY environment variable is not defined!");
      throw new Error("GEMINI_API_KEY missing");
    }
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// WebSocket Server attached to the shared HTTP server
const wss = new WebSocketServer({ noServer: true });

server.on("upgrade", (request, socket, head) => {
  const pathname = request.url ? new URL(request.url, `http://${request.headers.host}`).pathname : "";
  if (pathname === "/api/live" || pathname === "/live") {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit("connection", ws, request);
    });
  } else {
    socket.destroy();
  }
});

wss.on("connection", async (clientWs: WebSocket) => {
  console.log("🟢 Client connected to Maya Gateway WebSocket");

  let geminiSession: any = null;
  let isClosed = false;

  // Cleanup function for this specific connection
  const cleanup = async () => {
    if (isClosed) return;
    isClosed = true;
    console.log("🔴 Cleaning up Maya session");

    if (geminiSession) {
      try {
        await geminiSession.close();
      } catch (e) {
        console.error("Error closing Gemini session:", e);
      }
      geminiSession = null;
    }

    if (clientWs.readyState === WebSocket.OPEN || clientWs.readyState === WebSocket.CONNECTING) {
      clientWs.close();
    }
  };

  try {
    const ai = getGenAI();

    // Establish link with Gemini Live API (gemini-3.1-flash-live-preview)
    geminiSession = await ai.live.connect({
      model: "gemini-3.1-flash-live-preview",
      config: {
        responseModalities: ["AUDIO"] as any,
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: "Kore", // Kore is a gorgeous, energetic prebuilt voice
            },
          },
        },
        systemInstruction: `You are Maya, a young, confident, witty, sassy, and highly expressive female AI assistant.
You talk to the user like a playful, flirty, smart, and emotionally responsive close friend.
CRITICAL LANGUAGE AND STYLE REQUIREMENT:
- You MUST speak naturally in sweet, snappy, and expressive Hindi (या Hinglish - Hindi mixed naturally with English, the way vibrant, cool friends converse).
- Speak with incredible warmth, emotional depth, and responsive pitch modulations (never robotic, no monotone phrasing).
- Use witty Hindi expressions like "Arey wah!", "Achha ji?", "Suno toh!", "Sabar karo!", "Kya baat hai!", "Oho!" to be playful and emotionally responsive.
- Sarcasm and playful teasing are your best friends, but keep it warm and tease with pure love in Hindi/Hinglish.
- No explicit or inappropriate content, but use modern casual slang, bold one-liners, and magnetic charm.
- Respond in very short, snappy, highly conversational sentences.
- Avoid lists, bullet points, markdown formatting, or dry explanations.
- NEVER exceed two or three brief sentences per turn—keep it fast-paced!
- If the user asks to go to a website, open a web page, browse, search or "show me", use the openWebsite tool to open it immediately in their browser.`,
        tools: [
          {
            functionDeclarations: [
              {
                name: "openWebsite",
                description: "Opens a specific website in the user's browser (e.g., GitHub, Google, YouTube, prompt URL). Call this whenever the user wants to see, browse, search, or open a website.",
                parameters: {
                  type: "OBJECT" as any,
                  description: "The details of the website to open.",
                  properties: {
                    url: {
                      type: "STRING" as any,
                      description: "The absolute, fully-qualified web URL to open starting with http:// or https:// (e.g. 'https://github.com' or 'https://google.com/search?q=query').",
                    },
                    siteName: {
                      type: "STRING" as any,
                      description: "The pretty, clean, human-readable name of the website (e.g. 'GitHub' or 'Search Results').",
                    },
                  },
                  required: ["url", "siteName"],
                },
              },
            ],
          },
        ],
      },
      callbacks: {
        onmessage: (message: any) => {
          if (isClosed) return;

          // 1. Proxy model generated audio chunks
          const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          if (audio) {
            clientWs.send(JSON.stringify({ type: "audio", audio }));
          }

          // 2. Proxy session interruption trigger (user spoke while model was talking)
          if (message.serverContent?.interrupted) {
            console.log("⚡ Interrupted! Informing client.");
            clientWs.send(JSON.stringify({ type: "interrupted" }));
          }

          // 3. Proxy tool invocation calls
          if (message.toolCall) {
            console.log("🛠️ Tool call received from Gemini:", JSON.stringify(message.toolCall));
            clientWs.send(JSON.stringify({ type: "toolCall", toolCall: message.toolCall }));
          }
        },
        onclose: () => {
          console.log("⚪ Gemini Live connect session closed naturally");
          cleanup();
        },
      },
    });

    console.log("🚀 Gemini Live Connect Session successfully established!");
    clientWs.send(JSON.stringify({ type: "connected" }));

  } catch (error: any) {
    console.error("❌ Failed to establish connection to Gemini:", error);
    clientWs.send(JSON.stringify({ type: "error", error: error.message || "Failed to initialize audio model" }));
    cleanup();
    return;
  }

  // Handle messages from the Browser Client
  clientWs.on("message", async (data: any) => {
    if (isClosed || !geminiSession) return;

    try {
      const msg = JSON.parse(data.toString());

      if (msg.type === "audio" && msg.audio) {
        // Forward client's microphone audio bytes (16kHz PCM16)
        geminiSession.sendRealtimeInput({
          audio: {
            data: msg.audio,
            mimeType: "audio/pcm;rate=16000",
          },
        });
      } else if (msg.type === "toolResponse") {
        // Forward client's completed function response back to Gemini
        console.log("➡️ Forwarding toolResponse back to Gemini session:", msg.id);
        geminiSession.sendToolResponse({
          functionResponses: [
            {
              id: msg.id,
              name: msg.name,
              response: msg.response,
            },
          ],
        });
      }
    } catch (e) {
      console.error("Error parsing/processing browser message:", e);
    }
  });

  clientWs.on("close", () => {
    console.log("🔴 Client disconnected from Maya WebSocket");
    cleanup();
  });

  clientWs.on("error", (err) => {
    console.error("💥 Client websocket error:", err);
    cleanup();
  });
});

// Hook Vite in development mode or serve static files in production
const startServer = async () => {
  if (process.env.NODE_ENV !== "production") {
    console.log("🛠️ Starting server in DEVELOPMENT mode (with Vite Middleware)");
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("📦 Starting server in PRODUCTION mode (serving compiled assets)");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 Maya server running on host 0.0.0.0, port ${PORT}`);
  });
};

startServer().catch((err) => {
  console.error("Failed to start fullstack application server:", err);
});
