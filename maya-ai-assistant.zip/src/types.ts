export type LiveState = "disconnected" | "connecting" | "idle" | "listening" | "speaking";

export interface ToolCallPayload {
  functionCalls?: Array<{
    name: string;
    args: Record<string, any>;
    id: string;
  }>;
}

export interface WebPagePayload {
  url: string;
  siteName: string;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  type: "info" | "tool" | "error" | "speaking" | "listening";
  message: string;
  data?: any;
}
