import { useState, useEffect, useRef } from "react";
import { 
  Sparkles, 
  HelpCircle, 
  Mic2, 
  ExternalLink, 
  VolumeX, 
  Cpu, 
  RefreshCw, 
  History, 
  X,
  Compass
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import MayaOrb from "./components/MayaOrb";
import SassyControls from "./components/SassyControls";
import { LiveState, ActivityLog, WebPagePayload } from "./types";
import { floatTo16BitPCM, base64ToFloat32PCM, arrayBufferToBase64 } from "./utils/audio";

export default function App() {
  const [liveState, setLiveState] = useState<LiveState>("disconnected");
  const [isMuted, setIsMuted] = useState(false);
  const [micVolume, setMicVolume] = useState(0);
  const [speakerVolume, setSpeakerVolume] = useState(0);
  
  // Storage for logs
  const [logs, setLogs] = useState<ActivityLog[]>([
    {
      id: "init",
      timestamp: new Date().toLocaleTimeString(),
      type: "info",
      message: "Maya system initializing... Touch Core to link up.",
    },
  ]);

  // Active Tool state to pop open a beautiful overlay
  const [activeTool, setActiveTool] = useState<{
    id: string;
    url: string;
    siteName: string;
    timestamp: string;
    status: "pending" | "resolved";
  } | null>(null);

  // References to keep callbacks and streams protected from state recreation lags
  const wsRef = useRef<WebSocket | null>(null);
  
  // Audio playback references (for output at 24kHz)
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const scheduledNodesRef = useRef<AudioBufferSourceNode[]>([]);
  const speakerAnalyserRef = useRef<AnalyserNode | null>(null);
  
  // Audio recording references (for mic capture at 16kHz)
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const micProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const micAnalyserRef = useRef<AnalyserNode | null>(null);

  const isMutedRef = useRef(isMuted);
  const liveStateRef = useRef(liveState);

  // Keep references updated with state changes
  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  useEffect(() => {
    liveStateRef.current = liveState;
  }, [liveState]);

  // Append a message to our system/actions log
  const logInfo = (type: ActivityLog["type"], message: string, data?: any) => {
    setLogs((prev) => [
      {
        id: `log-${Date.now()}-${Math.random()}`,
        timestamp: new Date().toLocaleTimeString(),
        type,
        message,
        data,
      },
      ...prev.slice(0, 49), // Max 50 items
    ]);
  };

  // Stop everything and return to disconnected sleep state
  const shutdownConnection = () => {
    setLiveState("disconnected");
    logInfo("info", "Disconnecting session...");

    // 1. Close WebSockets
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch (e) {}
      wsRef.current = null;
    }

    // 2. Shut down speaker nodes
    stopAllPendingAudio();

    // 3. Stop mic stream
    if (micProcessorRef.current) {
      try { micProcessorRef.current.disconnect(); } catch (e) {}
      micProcessorRef.current = null;
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((track) => track.stop());
      micStreamRef.current = null;
    }
    if (inputAudioCtxRef.current) {
      try { inputAudioCtxRef.current.close(); } catch (e) {}
      inputAudioCtxRef.current = null;
    }
    if (outputAudioCtxRef.current) {
      try { outputAudioCtxRef.current.close(); } catch (e) {}
      outputAudioCtxRef.current = null;
    }

    setMicVolume(0);
    setSpeakerVolume(0);
    setActiveTool(null);
    logInfo("info", "Power down successful. Maya is asleep.");
  };

  // Instantly halt audio queue on interruption command
  const stopAllPendingAudio = () => {
    scheduledNodesRef.current.forEach((node) => {
      try {
        node.stop();
      } catch (e) {}
    });
    scheduledNodesRef.current = [];
    nextStartTimeRef.current = 0;
    setSpeakerVolume(0);
  };

  // Convert and schedule raw float array PCM chunks on the 24kHz speaker stream
  const playModelAudioChunk = (base64Audio: string) => {
    const audioCtx = outputAudioCtxRef.current;
    if (!audioCtx) return;

    try {
      // Decode raw 16-bit PCM back to Float32 details
      const float32PCM = base64ToFloat32PCM(base64Audio);
      const buffer = audioCtx.createBuffer(1, float32PCM.length, 24000); // Maya Voice outputs at 24kHz
      buffer.copyToChannel(float32PCM, 0);

      // Analyze speaker frequency waves on playback
      const analyser = speakerAnalyserRef.current;

      const source = audioCtx.createBufferSource();
      source.buffer = buffer;

      if (analyser) {
        source.connect(analyser);
      } else {
        source.connect(audioCtx.destination);
      }

      // Record nodes to terminate smoothly on user interruptions
      scheduledNodesRef.current.push(source);

      const currentTime = audioCtx.currentTime;
      if (nextStartTimeRef.current < currentTime) {
        // Schedule playing slightly ahead of clock to cover network delays
        nextStartTimeRef.current = currentTime + 0.05;
      }

      source.start(nextStartTimeRef.current);
      
      // Update state for visual wave sizing
      setLiveState("speaking");

      nextStartTimeRef.current += buffer.duration;

      source.onended = () => {
        // Clean up from scheduled array
        scheduledNodesRef.current = scheduledNodesRef.current.filter((n) => n !== source);
        
        // Wait till all scheduled nodes are completed to revert to idle listening state
        if (scheduledNodesRef.current.length === 0 && liveStateRef.current === "speaking") {
          setLiveState("idle");
          setSpeakerVolume(0);
        }
      };
    } catch (err: any) {
      console.error("Audio playback failure:", err);
    }
  };

  // Main loop to establish connection and start microphones
  const initMayaSession = async () => {
    if (liveState !== "disconnected") {
      shutdownConnection();
      return;
    }

    setLiveState("connecting");
    logInfo("info", "Prompting mic permissions & warming up Audio Contexts...");

    try {
      // 1. Force both contexts on user gestures to avoid modern browser restrictions
      const inputContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 }); // Rec at 16kHz
      const outputContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 }); // Output at 24kHz
      
      inputAudioCtxRef.current = inputContext;
      outputAudioCtxRef.current = outputContext;

      // 2. Attach output analyser for dynamic visual wave height
      const speakerAnalyser = outputContext.createAnalyser();
      speakerAnalyser.fftSize = 64;
      speakerAnalyser.connect(outputContext.destination);
      speakerAnalyserRef.current = speakerAnalyser;

      // 3. Capture microphone hardware
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;

      const source = inputContext.createMediaStreamSource(stream);
      const micAnalyser = inputContext.createAnalyser();
      micAnalyser.fftSize = 64;
      micAnalyserRef.current = micAnalyser;
      source.connect(micAnalyser);

      // Create processor to slice sound floats to base64 pcm chunks
      const processor = inputContext.createScriptProcessor(2048, 1, 1);
      micProcessorRef.current = processor;
      source.connect(processor);
      processor.connect(inputContext.destination);

      // 4. Connect WebSockets to full-stack proxy gateway
      const secureProtocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${secureProtocol}//${window.location.host}/api/live`;
      logInfo("info", `Opening socket to gateway: ${wsUrl}`);
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      processor.onaudioprocess = (e) => {
        // Block raw data flow when muted or not idle/listening
        if (isMutedRef.current || wsRef.current?.readyState !== WebSocket.OPEN) return;
        if (liveStateRef.current === "disconnected" || liveStateRef.current === "connecting") return;

        const channelData = e.inputBuffer.getChannelData(0);
        
        // Convert microphone floats directly to signed 16-bit PCM bytes
        const pcmBuffer = floatTo16BitPCM(channelData);
        const base64Audio = arrayBufferToBase64(pcmBuffer);

        wsRef.current?.send(
          JSON.stringify({
            type: "audio",
            audio: base64Audio,
          })
        );
      };

      ws.onopen = () => {
        logInfo("info", "Socket fully handshaked. Synchronizing with Maya's mind...");
      };

      ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === "connected") {
            setLiveState("idle");
            logInfo("info", "Maya is online! Say hello.");
          } else if (msg.type === "audio" && msg.audio) {
            playModelAudioChunk(msg.audio);
          } else if (msg.type === "interrupted") {
            logInfo("info", "Interruption! Stopping playback.");
            stopAllPendingAudio();
            setLiveState("listening");
          } else if (msg.type === "toolCall") {
            const toolCall = msg.toolCall;
            const functionCall = toolCall.functionCalls?.[0];
            
            if (functionCall && functionCall.name === "openWebsite") {
              const { url, siteName } = functionCall.args;
              logInfo("tool", `Maya used openWebsite to view: ${siteName}`, { url });
              
              // Record open website tool activation state
              setActiveTool({
                id: functionCall.id,
                url,
                siteName,
                timestamp: new Date().toLocaleTimeString(),
                status: "pending"
              });

              // Instantly attempt automated redirect in background
              try {
                window.open(url, "_blank");
              } catch (e) {
                console.warn("Automated popup blocked, user must click interactive card:", e);
              }

              // Send instant resolution tool response so Gemini session can resume talking
              ws.send(JSON.stringify({
                type: "toolResponse",
                id: functionCall.id,
                name: "openWebsite",
                response: {
                  output: {
                    success: true,
                    siteOpened: siteName,
                    url: url,
                    status: "Proposed redirect popup or interactive unlock card to user."
                  }
                }
              }));
            }
          } else if (msg.type === "error") {
            logInfo("error", `Gateway Error: ${msg.error}`);
            shutdownConnection();
          }
        } catch (e: any) {
          console.error("Message processing error:", e);
        }
      };

      ws.onclose = (ev) => {
        logInfo("info", `Socket closed: ${ev.reason || "Connection dropped"}`);
        shutdownConnection();
      };

      ws.onerror = (err) => {
        logInfo("error", "Socket error. Check connection details.");
        console.error("WS connection error:", err);
        shutdownConnection();
      };

    } catch (error: any) {
      logInfo("error", `Initialization failed: ${error.message || error}`);
      shutdownConnection();
    }
  };

  // Run constant micro animation loops to map volume levels to the glowing elements
  useEffect(() => {
    let animationFrameId: number;
    
    // Low-pass calculations for mic and speaker volume inputs
    const micData = new Uint8Array(32);
    const speakerData = new Uint8Array(32);

    const updateVolumeStates = () => {
      // 1. Analyze user mic input volume
      if (liveState === "listening" && micAnalyserRef.current && !isMuted) {
        micAnalyserRef.current.getByteFrequencyData(micData);
        let sum = 0;
        for (let i = 0; i < micData.length; i++) {
          sum += micData[i];
        }
        const average = sum / micData.length;
        setMicVolume(Math.min(1, average / 120)); // scale amplitude
      } else {
        setMicVolume(0);
      }

      // 2. Analyze Maya output speaker volume
      if (liveState === "speaking" && speakerAnalyserRef.current) {
        speakerAnalyserRef.current.getByteFrequencyData(speakerData);
        let sum = 0;
        for (let i = 0; i < speakerData.length; i++) {
          sum += speakerData[i];
        }
        const average = sum / speakerData.length;
        setSpeakerVolume(Math.min(1, average / 120));
      } else {
        setSpeakerVolume(0);
      }

      // 3. Continuously transition state based on sound if needed, but Gemini handles VAD
      animationFrameId = requestAnimationFrame(updateVolumeStates);
    };

    updateVolumeStates();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [liveState, isMuted]);

  // Clean up socket resources on unmounting
  useEffect(() => {
    return () => {
      shutdownConnection();
    };
  }, []);

  // Handle manual trigger click for interactive tools
  const handleOpenToolSite = (url: string) => {
    window.open(url, "_blank");
    if (activeTool) {
      setActiveTool({ ...activeTool, status: "resolved" });
      setTimeout(() => {
        setActiveTool(null);
      }, 1000);
    }
  };

  return (
    <div id="maya-full-app" className="min-h-screen bg-[#020205] text-white flex flex-col justify-between selection:bg-[#00F0FF]/25 selection:text-[#00F0FF] relative overflow-hidden font-sans">
      
      {/* Absolute floating glow blurs from Vibrant Cyberpunk Palette */}
      <div className="absolute inset-0 opacity-15 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-[#00F0FF] blur-[140px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-[#0055FF] blur-[140px]" />
      </div>

      {/* Sleek Header (Futuristic Hologram Style) */}
      <header className="border-b border-white/5 bg-[#020205]/80 backdrop-blur-md sticky top-0 z-20 px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#00F0FF] to-[#0055FF] flex items-center justify-center">
            <div className="w-4 h-4 bg-white rounded-full shadow-[0_0_8px_white]"></div>
          </div>
          <span className="text-2xl font-black tracking-tighter">
            MAYA <span className="text-[#00F0FF]">AI</span>
          </span>
        </div>

        {/* Dynamic Connected Indicator & Info */}
        <div className="flex items-center gap-6 text-sm font-medium opacity-80">
          <span className="font-mono text-xs text-neutral-400 hidden sm:inline">GEMINI BIDI LIVE PREVIEW</span>
          <div className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/5">
            <div className={`w-2 h-2 rounded-full transition-all duration-300 ${
              liveState === "disconnected" ? "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]" :
              liveState === "connecting" ? "bg-[#0055FF] shadow-[0_0_8px_rgba(0,85,255,0.7)] animate-ping" :
              "bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(0,240,255,0.7)]"
            }`} />
            <span className="text-[11px] font-bold font-mono tracking-wider uppercase">
              {liveState === "disconnected" ? "Offline" : liveState === "connecting" ? "Syncing" : "LIVE CAPTURE"}
            </span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col md:flex-row items-center justify-center p-6 gap-8 max-w-7xl mx-auto w-full relative z-10">
        
        {/* Visual Central Column (Maya holographic orb) */}
        <div className="flex-1 flex items-center justify-center relative w-full">
          <MayaOrb 
            state={liveState} 
            onClick={initMayaSession}
            micVolume={micVolume}
            speakerVolume={speakerVolume}
          />
        </div>

        {/* Informational Right-Column card */}
        <div className="w-full md:w-[380px] flex flex-col space-y-6">
          <SassyControls 
            isMuted={isMuted}
            onToggleMute={() => setIsMuted(prev => !prev)}
          />

          {/* Activity/Logs Ticker Card styled with Vibrant accents */}
          <div className="bg-[#020205]/80 border border-white/5 rounded-2xl p-5 space-y-3 shadow-2xl">
            <div className="flex items-center justify-between text-xs text-neutral-400 font-mono tracking-widest uppercase border-b border-white/5 pb-2">
              <span className="flex items-center space-x-1.5">
                <History className="w-3.5 h-3.5 text-[#00F0FF]" />
                <span className="font-bold text-white">Action stream</span>
              </span>
              <span className="text-[10px] text-neutral-500 uppercase">Live link</span>
            </div>

            <div className="h-40 overflow-y-auto space-y-3 pr-1 scrollbar-thin scrollbar-thumb-neutral-800">
              {logs.map((log) => (
                <div key={log.id} className="text-xs flex items-start space-x-2.5 leading-relaxed">
                  <span className="text-[10px] font-mono text-neutral-600 select-none pt-0.5">{log.timestamp}</span>
                  <span className={`px-2 py-0.5 rounded shrink-0 font-mono text-[8px] uppercase tracking-wider font-bold ${
                    log.type === "error" ? "bg-red-500/10 text-red-400 border border-red-500/15" :
                    log.type === "tool" ? "bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/15" :
                    "bg-[#0055FF]/15 text-[#0055FF] border border-[#0055FF]/15"
                  }`}>
                    {log.type}
                  </span>
                  <p className="text-[#9ea3b0] font-sans tracking-wide">
                    {log.message}
                    {log.data?.url && (
                      <span className="block text-[10px] text-neutral-500 break-all font-mono mt-0.5">{log.data.url}</span>
                    )}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Floating Interactive Popup Card for Tool Action (openWebsite) */}
      <AnimatePresence>
        {activeTool && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 30 }}
            className="fixed bottom-6 left-6 right-6 md:left-auto md:right-6 md:w-96 bg-[#020205] border-2 border-[#00F0FF]/40 shadow-[0_10px_40px_rgba(0,240,255,0.25)] rounded-2xl p-5 z-50 text-white space-y-4"
          >
            <div className="flex items-center justify-between border-b border-white/5 pb-2">
              <span className="flex items-center space-x-2 text-[#00F0FF] text-xs font-mono font-bold uppercase tracking-wider">
                <Compass className="w-4 h-4 animate-spin" />
                <span>Redirect requested</span>
              </span>
              <button 
                onClick={() => setActiveTool(null)}
                className="text-neutral-500 hover:text-neutral-300 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <h4 className="text-base font-bold font-sans tracking-tight">
                Maya wants to show you: {activeTool.siteName}
              </h4>
              <p className="text-xs text-neutral-400 mt-1">
                Your browser might blocks default popup redirects. Click the launch button below to proceed!
              </p>
              <div className="text-[10px] font-mono text-[#00F0FF]/90 break-all bg-[#020205] p-2.5 rounded-lg mt-3 border border-white/5">
                {activeTool.url}
              </div>
            </div>

            <div className="flex items-center space-x-2 pt-2">
              <button
                onClick={() => handleOpenToolSite(activeTool.url)}
                className="w-full flex items-center justify-center space-x-2 py-3 px-4 bg-gradient-to-r from-[#00F0FF] to-[#0055FF] hover:opacity-90 font-sans font-bold text-sm rounded-xl transition-all shadow-lg cursor-pointer"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Launch {activeTool.siteName}</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Aesthetic Footer with Vibrant Palette style matching */}
      <footer className="border-t border-white/5 bg-[#020205] px-8 py-5 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 z-10">
        <p className="font-mono tracking-wider uppercase text-[10px]">
          MAYA COMPANION // VIBRANT VOICE SUITE // PORT 3000
        </p>
        <div className="flex flex-wrap items-center gap-6 font-sans text-[11px] font-semibold mt-2 sm:mt-0 text-neutral-400">
          <div className="flex items-center gap-1.5 font-mono">
            <span className="text-[9px] uppercase tracking-widest opacity-40">Personality:</span>
            <span className="text-[#00F0FF]">Sassy & Smart</span>
          </div>
          <div className="w-[1px] h-3 bg-white/10 hidden sm:block"></div>
          <div className="flex items-center gap-1.5 font-mono">
            <span className="text-[9px] uppercase tracking-widest opacity-40">Mode:</span>
            <span className="text-white">Voice-Only</span>
          </div>
          <div className="w-[1px] h-3 bg-white/10 hidden sm:block"></div>
          <div className="flex items-center gap-1.5 font-mono">
            <span className="text-[9px] uppercase tracking-widest opacity-40">Mood:</span>
            <span className="text-[#0055FF]">Warm Expressive</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
