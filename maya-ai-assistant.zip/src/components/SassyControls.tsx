import { Sliders, VolumeX, Volume2, ShieldCheck, HelpCircle } from "lucide-react";
import { motion } from "motion/react";

interface SassyControlsProps {
  isMuted: boolean;
  onToggleMute: () => void;
  sassyLevel?: number;
  confidence?: number;
  playfulness?: number;
}

export default function SassyControls({
  isMuted,
  onToggleMute,
  sassyLevel = 95,
  confidence = 99,
  playfulness = 90,
}: SassyControlsProps) {
  return (
    <div id="companion-controls-card" className="w-full max-w-sm bg-[#020205]/80 border border-white/5 backdrop-blur-md rounded-2xl p-5 mx-auto shadow-2xl space-y-4">
      {/* Card Header */}
      <div className="flex items-center justify-between border-b border-white/5 pb-3">
        <div className="flex items-center space-x-2">
          <Sliders className="w-4 h-4 text-[#00F0FF]" />
          <h3 className="text-sm font-sans font-bold text-white tracking-tight uppercase">Companion Core Tune</h3>
        </div>
        <div className="flex items-center space-x-1.5 px-2 py-0.5 rounded-full bg-[#00F0FF]/15 border border-[#00F0FF]/25">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00F0FF] animate-pulse" />
          <span className="text-[10px] font-bold font-sans text-[#00F0FF] uppercase tracking-widest">Sassy Mode</span>
        </div>
      </div>

      {/* Sliders Area (Sassy Companion Tuning parameters) */}
      <div className="space-y-3">
        {/* Sassy level */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs font-mono text-neutral-400">
            <span>Sassy retorts</span>
            <span className="text-[#00F0FF] font-bold">{sassyLevel}%</span>
          </div>
          <div className="relative w-full h-1 bg-neutral-900 rounded-full overflow-hidden">
            <div className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#00F0FF] to-[#0055FF] rounded-full" style={{ width: `${sassyLevel}%` }} />
          </div>
        </div>

        {/* Confidence Level */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs font-mono text-neutral-400">
            <span>Confidence index</span>
            <span className="text-[#0055FF] font-bold">{confidence}%</span>
          </div>
          <div className="relative w-full h-1 bg-neutral-900 rounded-full overflow-hidden">
            <div className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#0055FF] to-[#00F0FF] rounded-full" style={{ width: `${confidence}%` }} />
          </div>
        </div>

        {/* Playfulness Level */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs font-mono text-neutral-400">
            <span>Playful teasing</span>
            <span className="text-[#00F0FF] font-bold">{playfulness}%</span>
          </div>
          <div className="relative w-full h-1 bg-neutral-900 rounded-full overflow-hidden">
            <div className="absolute top-0 left-0 h-full bg-gradient-to-r from-cyan-400 to-[#0055FF] rounded-full" style={{ width: `${playfulness}%` }} />
          </div>
        </div>
      </div>

      {/* Extra Action Buttons */}
      <div className="flex items-center space-x-3 pt-2">
        {/* Mute Input Button */}
        <button
          onClick={onToggleMute}
          className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-xl border text-xs font-bold font-sans transition-all cursor-pointer ${
            isMuted
              ? "bg-red-500/10 hover:bg-red-500/20 border-red-500/30 text-red-400"
              : "bg-white/5 hover:bg-white/10 hover:border-white/10 border-white/5 text-neutral-200"
          }`}
        >
          {isMuted ? (
            <>
              <VolumeX className="w-3.5 h-3.5" />
              <span>Unmute Microphone</span>
            </>
          ) : (
            <>
              <Volume2 className="w-3.5 h-3.5 text-neutral-400" />
              <span>Mute Microphone</span>
            </>
          )}
        </button>
      </div>

      {/* Safety footprint */}
      <div className="flex items-center justify-start space-x-1.5 text-[10px] text-neutral-500 font-mono pt-1">
        <ShieldCheck className="w-3 h-3 text-[#00F0FF]" />
        <span>VAD Voice Detection Encrypted Gateway</span>
      </div>
    </div>
  );
}
