import { motion } from "motion/react";
import { Power, Mic, Volume2, Sparkles, RefreshCw } from "lucide-react";
import { LiveState } from "../types";

interface MayaOrbProps {
  state: LiveState;
  onClick: () => void;
  micVolume: number; // 0 to 1
  speakerVolume: number; // 0 to 1
}

export default function MayaOrb({ state, onClick, micVolume, speakerVolume }: MayaOrbProps) {
  // Map states to Vibrant Futuristic blue/cyan styles
  const getColors = () => {
    switch (state) {
      case "disconnected":
        return {
          glow: "rgba(0, 85, 255, 0.1)",
          border: "border-neutral-900",
          bg: "bg-[#020205]",
          core: "from-neutral-950 to-[#020205]",
          iconColor: "text-zinc-600",
          text: "text-neutral-500",
          wave: "rgba(0, 85, 255, 0.05)",
        };
      case "connecting":
        return {
          glow: "rgba(0, 229, 255, 0.35)",
          border: "border-[#00E5FF]/30",
          bg: "bg-[#020205]",
          core: "from-[#00E5FF]/10 to-[#020205]",
          iconColor: "text-cyan-400 animate-pulse",
          text: "text-[#00E5FF]",
          wave: "rgba(0, 229, 255, 0.25)",
        };
      case "idle":
        return {
          glow: "rgba(0, 114, 255, 0.3)",
          border: "border-[#0072FF]/20",
          bg: "bg-[#020205]",
          core: "from-[#0072FF]/10 to-[#020205]",
          iconColor: "text-[#0072FF]",
          text: "text-neutral-300",
          wave: "rgba(0, 114, 255, 0.2)",
        };
      case "listening":
        return {
          glow: "rgba(0, 240, 255, 0.5)",
          border: "border-[#00F0FF]/40",
          bg: "bg-[#020205]",
          core: "from-[#00F0FF]/25 to-[#020205]",
          iconColor: "text-[#00F0FF]",
          text: "text-[#00F0FF] font-black",
          wave: "rgba(0, 240, 255, 0.35)",
        };
      case "speaking":
        return {
          glow: "rgba(0, 85, 255, 0.6)",
          border: "border-[#0055FF]/40",
          bg: "bg-[#020205]",
          core: "from-[#0055FF]/20 to-[#00F0FF]/15",
          iconColor: "text-white",
          text: "text-neutral-100",
          wave: "rgba(0, 85, 255, 0.45)",
        };
    }
  };

  const colors = getColors();

  const activeVolume = state === "listening" ? micVolume : state === "speaking" ? speakerVolume : 0;
  const scaleMultiplier = 1 + activeVolume * 0.4;
  const glowIntensity = 40 + activeVolume * 60;

  return (
    <div id="maya-orb-container" className="flex flex-col items-center justify-center select-none py-12">
      {/* Absolute floating decorations from Vibrant Palette */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {state !== "disconnected" && (
          <>
            <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-[#00F0FF] opacity-10 blur-[130px]" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-[#0055FF] opacity-10 blur-[130px]" />
          </>
        )}
      </div>

      {/* Main Orb concentric circles block */}
      <div className="relative flex items-center justify-center w-[460px] h-[460px]">
        {/* Concentric borders from design layout */}
        <div className="absolute w-[450px] h-[450px] rounded-full border border-white/5 pointer-events-none" />
        <div className="absolute w-[380px] h-[380px] rounded-full border border-white/10 pointer-events-none" />
        <div className="absolute w-[300px] h-[300px] rounded-full border-2 border-[#00F0FF]/10 pointer-events-none" />
        
        {/* Glowing Background Active Waves */}
        {state !== "disconnected" && (
          <>
            {/* Wave 1 */}
            <motion.div
              id="wave-1"
              className="absolute inset-0 rounded-full"
              style={{
                background: `radial-gradient(circle, ${colors.glow} 0%, rgba(9,9,11,0) 70%)`,
                scale: scaleMultiplier,
              }}
              animate={
                state === "speaking" || state === "listening"
                  ? { scale: [1, 1.15, 1] }
                  : { scale: [0.95, 1, 0.95] }
              }
              transition={{
                duration: state === "speaking" ? 1.5 : 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
            
            {/* Wave 2 */}
            <motion.div
              id="wave-2"
              className="absolute w-[310px] h-[310px] rounded-full border border-dashed opacity-30"
              style={{
                borderColor: colors.wave,
              }}
              animate={{ rotate: 360 }}
              transition={{
                duration: state === "connecting" ? 4 : 25,
                repeat: Infinity,
                ease: "linear",
              }}
            />
          </>
        )}

        {/* Outer Circular Rim with Vibrant Gradient and Core Shadow */}
        <motion.button
          id="maya-orb-trigger"
          onClick={onClick}
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.96 }}
          style={{
            boxShadow: state !== "disconnected" 
              ? `0 0 ${glowIntensity}px rgba(0, 240, 255, 0.4)`
              : "none",
          }}
          className="relative z-10 w-[240px] h-[240px] rounded-full bg-gradient-to-b from-[#00F0FF] to-[#0055FF] p-[3px] transition-all duration-500 cursor-pointer"
        >
          {/* Internal Radial Mask for Hologram Effect */}
          <div className="w-full h-full rounded-full bg-[#020205] flex flex-col items-center justify-center overflow-hidden relative">
            
            {/* Aesthetic bottom overlay gradient from the design sheet */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#00F0FF]/15 to-transparent pointer-events-none" />

            {/* Micro Sparkles of Maya */}
            {state === "speaking" && (
              <div className="absolute inset-0 flex justify-center items-center pointer-events-none">
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 0.8, 0] }}
                  transition={{ duration: 1.4, repeat: Infinity }}
                  className="absolute top-1/4 right-1/4"
                >
                  <Sparkles className="w-5 h-5 text-[#00F0FF]" />
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 0.7, 0] }}
                  transition={{ duration: 1.8, repeat: Infinity, delay: 0.4 }}
                  className="absolute bottom-1/4 left-1/3"
                >
                  <Sparkles className="w-4 h-4 text-[#0055FF]" />
                </motion.div>
              </div>
            )}

            {/* Inner dynamic core containing icons and status */}
            <div className="flex flex-col items-center justify-center text-center space-y-1.5 z-10 pointer-events-none">
              
              {/* Dynamic Action Icon */}
              <motion.div
                animate={
                  state === "speaking"
                    ? { scale: [1, 1.12, 1], y: [0, -3, 0] }
                    : state === "listening"
                    ? { scale: [1, 1.1, 1] }
                    : {}
                }
                transition={{ duration: 1, repeat: Infinity }}
                className={`p-3.5 rounded-full bg-[#020205]/95 border border-white/5 ${colors.iconColor} transition-colors duration-500`}
              >
                {state === "disconnected" && <Power className="w-7 h-7" />}
                {state === "connecting" && <RefreshCw className="w-7 h-7 animate-spin text-[#00E5FF]" />}
                {state === "idle" && <Mic className="w-7 h-7" />}
                {state === "listening" && <Mic className="w-7 h-7 text-[#00E5FF] animate-pulse" />}
                {state === "speaking" && <Volume2 className="w-7 h-7 text-white" />}
              </motion.div>

              {/* Central text prompt */}
              <div className="flex flex-col items-center select-none pt-1">
                <span className="text-white text-base font-black tracking-tight uppercase">
                  {state === "disconnected" && "WAKE MAYA"}
                  {state === "connecting" && "SYNCING..."}
                  {state === "idle" && "READY"}
                  {state === "listening" && "LISTENING"}
                  {state === "speaking" && "MAYA TALKING"}
                </span>
                <span className="text-[9px] uppercase tracking-[0.15em] text-neutral-400/80 font-mono">
                  {state === "disconnected" && "Tap to link"}
                  {state === "connecting" && "Calibrating voice"}
                  {state === "idle" && "Say something"}
                  {state === "listening" && "Tease her..."}
                  {state === "speaking" && "Listen closely"}
                </span>
              </div>
            </div>

            {/* Interactive Dynamic Waveform Bar inside the Orb when active */}
            {(state === "listening" || state === "speaking") && (
              <div className="absolute bottom-6 left-8 right-8 flex items-end justify-center space-x-1.5 h-6">
                {[...Array(7)].map((_, i) => {
                  const baseHeight = [12, 22, 38, 54, 42, 28, 14][i];
                  const dynamicScale = activeVolume > 0.02 ? activeVolume * 1.5 : 0.1;
                  const finalHeight = Math.max(3, Math.min(22, baseHeight * dynamicScale));
                  
                  return (
                    <motion.div
                      key={i}
                      animate={{
                        height: [finalHeight * 0.8, finalHeight * 1.2, finalHeight * 0.8],
                      }}
                      transition={{
                        duration: 0.25 + i * 0.04,
                        repeat: Infinity,
                        ease: "linear",
                      }}
                      className={`w-[3px] rounded-full ${
                        state === "listening" ? "bg-[#00F0FF] shadow-[0_0_8px_rgba(0,240,255,0.6)]" : "bg-white shadow-[0_0_8px_rgba(255,255,255,0.4)]"
                      }`}
                      style={{ height: `${finalHeight}px` }}
                    />
                  );
                })}
              </div>
            )}
          </div>
        </motion.button>
      </div>

      {/* Narrative Subtitle State */}
      <div className="mt-4 text-center px-6 max-w-sm z-10">
        <motion.p
          key={state}
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          className={`text-sm tracking-wide leading-relaxed font-semibold transition-colors duration-500 font-sans ${colors.text}`}
        >
          {state === "disconnected" && "⚠️ Maya is asleep. Wake up the sassy goddess to get teased."}
          {state === "connecting" && "🔮 Establishing socket links. Maya is loading up her snappy comebacks..."}
          {state === "idle" && "✨ Linked! Standard voice detection active. Say something witty."}
          {state === "listening" && "🎙️ Voice detected! Tell Maya what is on your mind."}
          {state === "speaking" && "💋 Sassy comment incoming! Listen closely..."}
        </motion.p>
      </div>
    </div>
  );
}
